<?php
// Diagnostic endpoint - helps identify configuration and startup issues
// Place this at: /api/diagnostic.php
// Access via: https://namastekalyan.asianwokandgrill.in/api/diagnostic.php

header('Content-Type: application/json; charset=utf-8');

$diagnostic = [
    'php_version' => PHP_VERSION,
    'sapi' => PHP_SAPI,
    'base_dir' => __DIR__,
    'extensions' => [
        'pdo' => extension_loaded('pdo') ? 'loaded' : 'MISSING',
        'pdo_mysql' => extension_loaded('pdo_mysql') ? 'loaded' : 'MISSING',
    ],
];

// Check critical files
$files = [
    'bootstrap.php' => __DIR__ . '/bootstrap.php',
    'index.php' => __DIR__ . '/index.php',
    'src/Routes/ActionRouter.php' => __DIR__ . '/src/Routes/ActionRouter.php',
];

$diagnostic['files'] = [];
foreach ($files as $name => $path) {
    $diagnostic['files'][$name] = is_file($path) ? 'exists' : 'MISSING';
}

// Load .env
$diagnostic['env'] = [];
$envFile = __DIR__ . '/.env';
if (is_file($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
    foreach ($lines as $line) {
        $trimmed = trim((string) $line);
        if ($trimmed === '' || substr($trimmed, 0, 1) === '#') continue;
        $parts = explode('=', $trimmed, 2);
        if (count($parts) === 2) {
            $key = trim((string) $parts[0]);
            if (in_array($key, ['DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'APP_ENV', 'APP_URL'])) {
                $diagnostic['env'][$key] = trim((string) $parts[1], "\"'");
            }
        }
    }
    $diagnostic['env_file'] = 'found';
} else {
    $diagnostic['env_file'] = 'MISSING';
}

// Try database connection
$diagnostic['database'] = [];
if ($diagnostic['extensions']['pdo_mysql'] === 'loaded' && $diagnostic['env']) {
    try {
        $_ENV = $diagnostic['env'];
        $host = trim((string) ($_ENV['DB_HOST'] ?? ''));
        $port = trim((string) ($_ENV['DB_PORT'] ?? '3306'));
        $name = $_ENV['DB_NAME'] ?? '';
        $user = $_ENV['DB_USER'] ?? '';
        $pass = $_ENV['DB_PASS'] ?? '';
        
        if (strpos($host, ':') !== false) {
            [$hostPart, $portPart] = explode(':', $host, 2);
            if ($hostPart !== '') $host = $hostPart;
            if ($portPart !== '' && ctype_digit($portPart)) $port = $portPart;
        }
        
        $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";
        $pdo = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $diagnostic['database']['status'] = 'connected';
        
        $stmt = $pdo->query('SELECT COUNT(*) as cnt FROM users');
        $row = $stmt->fetch();
        $diagnostic['database']['users_count'] = $row['cnt'] ?? 0;
    } catch (PDOException $e) {
        $diagnostic['database']['status'] = 'FAILED';
        $diagnostic['database']['error_code'] = $e->getCode();
        $diagnostic['database']['error_msg'] = $e->getMessage();
    }
} else {
    $diagnostic['database']['status'] = 'skipped - pdo_mysql not available or env not loaded';
}

echo json_encode($diagnostic, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
